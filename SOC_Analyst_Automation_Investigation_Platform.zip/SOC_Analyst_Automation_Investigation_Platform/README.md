# SOC Analyst Automation & Investigation Platform

A graduate-level learning prototype that generates **synthetic authentication logs**, detects suspicious patterns with Python, optionally indexes events in Elasticsearch, and provides alert summaries with optional LLM assistance.

## Architecture
1. `src/generate_logs.py` generates sample login events.
2. `src/detect.py` detects repeated failed logins and success after repeated failures.
3. `src/investigate.py` produces investigation notes; optional LLM enrichment is disabled by default.
4. `src/main.py` orchestrates the pipeline and saves JSON/CSV output.
5. `src/ingest_elasticsearch.py` optionally indexes events and alerts in Elasticsearch for Kibana exploration.

## Setup (Python 3.10+)
Windows PowerShell:
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```
macOS/Linux:
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

## Run locally without Elasticsearch
```bash
python -m src.main --count 120 --seed 7
```
Output files: `output/events.json`, `output/alerts.json`, `output/alerts.csv`.

## Run with Elasticsearch and Kibana
Start local services:
```bash
docker compose up -d
```
Wait for Elasticsearch to become available, then:
```bash
python -m src.main --count 120 --seed 7 --index
```
Open Kibana at http://localhost:5601 and create data views `soc-events-*` and `soc-alerts-*`, using `@timestamp` as the time field.

This local Docker demo disables Elasticsearch security for convenience. Do not expose its ports to the public internet.

## Optional LLM investigation
Set `ENABLE_LLM=true` and `OPENAI_API_KEY` in `.env` to enable optional LLM-based notes. It is off by default. Do not send real logs or sensitive information to an external service without authorisation.

## Detection rules
- AUTH-001: at least 5 failed logins for the same user/source IP within 10 minutes.
- AUTH-002: a successful login after at least 3 recent failed attempts for the same user/source IP.
Thresholds are illustrative, not universal indicators of compromise.

## Honest project description
This is a prototype using generated logs. It does not collect live endpoint/network logs, block attacks, or replace a production SIEM. Treat detection and LLM output as analyst assistance and validate alerts against trusted evidence.
