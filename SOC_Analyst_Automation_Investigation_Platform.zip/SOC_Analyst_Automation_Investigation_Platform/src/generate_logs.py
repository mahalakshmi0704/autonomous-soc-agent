from datetime import datetime, timedelta, timezone
import random
import uuid

USERS = ["asha", "rahul", "maya", "analyst", "admin", "kiran"]
# Documentation-only IP ranges, used so examples don't point at real clients.
SOURCE_IPS = ["192.0.2.10", "192.0.2.11", "198.51.100.24", "203.0.113.7"]

def generate_events(count=100, seed=7):
    if count < 1:
        raise ValueError("count must be at least 1")
    rng = random.Random(seed)
    now = datetime.now(timezone.utc).replace(microsecond=0)
    events = []
    for i in range(count):
        user = rng.choice(USERS)
        ip = rng.choice(SOURCE_IPS)
        failed = rng.random() < 0.28
        ts = now - timedelta(minutes=rng.randint(0, 60), seconds=rng.randint(0, 59))
        action = "login_failure" if failed else "login_success"
        events.append({
            "@timestamp": ts.isoformat().replace("+00:00", "Z"),
            "event": {"id": str(uuid.uuid4()), "category": "authentication",
                      "action": action, "outcome": "failure" if failed else "success",
                      "dataset": "soc.synthetic_auth"},
            "user": {"name": user},
            "source": {"ip": ip},
            "host": {"name": f"lab-host-{rng.randint(1, 4)}"},
            "message": f"Synthetic authentication {action} for {user} from {ip}",
            "labels": {"synthetic": True, "generator": "soc-prototype"},
            "event_sequence": i + 1
        })

    # Inject a known demonstration scenario so a run reliably produces an alert.
    base = now - timedelta(minutes=3)
    for j in range(6):
        ip, user = "203.0.113.7", "admin"
        events.append({
            "@timestamp": (base + timedelta(seconds=15*j)).isoformat().replace("+00:00", "Z"),
            "event": {"id": str(uuid.uuid4()), "category": "authentication",
                      "action": "login_failure", "outcome": "failure",
                      "dataset": "soc.synthetic_auth"},
            "user": {"name": user}, "source": {"ip": ip},
            "host": {"name": "lab-host-1"},
            "message": f"Synthetic repeated login failure for {user} from {ip}",
            "labels": {"synthetic": True, "generator": "soc-prototype",
                       "scenario": "repeated_failures"},
            "event_sequence": count + j + 1
        })
    return sorted(events, key=lambda e: e["@timestamp"])
