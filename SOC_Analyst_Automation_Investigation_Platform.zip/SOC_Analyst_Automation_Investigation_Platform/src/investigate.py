import json
from .config import ENABLE_LLM, OPENAI_API_KEY, OPENAI_MODEL

def build_investigation(alert):
    rule = alert.get("rule", {}).get("name", "Unknown rule")
    user = alert.get("user", {}).get("name", "unknown")
    ip = alert.get("source", {}).get("ip", "unknown")
    count = alert.get("event_count", 0)
    severity = alert.get("severity", "unknown")
    result = dict(alert)
    result["investigation"] = {
        "summary": (
            f"Rule '{rule}' triggered for user '{user}' from source IP '{ip}'. "
            f"The detection references {count} event(s). Demo severity: {severity}. "
            "Verify the timeline and account activity with approved log sources. Repeated failures "
            "can also result from mistyped passwords or stale credentials."
        ),
        "recommended_steps": [
            "Review timestamps and the sequence of authentication events.",
            "Check whether the source IP and account activity are expected.",
            "Correlate with approved endpoint, VPN, identity-provider and network logs if available.",
            "Escalate using the organisation's incident-response procedure if evidence supports compromise."
        ],
        "llm_assisted": False,
        "disclaimer": "Recommendations are analyst prompts, not an automated incident verdict."
    }
    if ENABLE_LLM and OPENAI_API_KEY:
        try:
            result["investigation"]["llm_notes"] = call_llm(alert)
            result["investigation"]["llm_assisted"] = True
        except Exception as exc:
            result["investigation"]["llm_error"] = type(exc).__name__
    return result

def call_llm(alert):
    import requests
    payload = {
        "model": OPENAI_MODEL,
        "messages": [
            {"role": "system", "content":
             "Assist a junior SOC analyst. Use only supplied evidence; do not invent facts. "
             "Give a short summary, possible benign explanations and verification steps. "
             "State that this is synthetic demo data."},
            {"role": "user", "content": json.dumps(alert, ensure_ascii=False)}
        ],
        "temperature": 0.2
    }
    response = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={"Authorization": f"Bearer {OPENAI_API_KEY}",
                 "Content-Type": "application/json"},
        json=payload, timeout=30
    )
    response.raise_for_status()
    return response.json()["choices"][0]["message"]["content"]
