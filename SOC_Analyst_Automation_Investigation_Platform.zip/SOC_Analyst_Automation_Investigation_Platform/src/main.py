import argparse
import csv
import json
from pathlib import Path
from .generate_logs import generate_events
from .detect import detect_alerts
from .investigate import build_investigation

OUTPUT = Path("output")

def write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

def write_csv(path, alerts):
    path.parent.mkdir(parents=True, exist_ok=True)
    columns = ["timestamp", "alert_id", "rule_id", "rule_name", "severity",
               "username", "source_ip", "event_count", "summary"]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for a in alerts:
            writer.writerow({
                "timestamp": a.get("@timestamp", ""),
                "alert_id": a.get("alert", {}).get("id", ""),
                "rule_id": a.get("rule", {}).get("id", ""),
                "rule_name": a.get("rule", {}).get("name", ""),
                "severity": a.get("severity", ""),
                "username": a.get("user", {}).get("name", ""),
                "source_ip": a.get("source", {}).get("ip", ""),
                "event_count": a.get("event_count", 0),
                "summary": a.get("investigation", {}).get("summary", "")
            })

def main():
    parser = argparse.ArgumentParser(description="SOC Analyst Automation & Investigation Platform")
    parser.add_argument("--count", type=int, default=100, help="Random synthetic events to generate")
    parser.add_argument("--seed", type=int, default=7, help="Seed for reproducible random events")
    parser.add_argument("--index", action="store_true", help="Also index events and alerts in Elasticsearch")
    args = parser.parse_args()

    events = generate_events(args.count, args.seed)
    alerts = detect_alerts(events)
    investigated = [build_investigation(a) for a in alerts]
    write_json(OUTPUT / "events.json", events)
    write_json(OUTPUT / "alerts.json", investigated)
    write_csv(OUTPUT / "alerts.csv", investigated)

    print(f"Generated synthetic events: {len(events)}")
    print(f"Alerts detected: {len(alerts)}")
    print(f"Output directory: {OUTPUT.resolve()}")

    if args.index:
        try:
            from .ingest_elasticsearch import index_documents
            print("Indexed events:", index_documents("soc-events", events))
            print("Indexed alerts:", index_documents("soc-alerts", investigated))
        except Exception as exc:
            print(f"Elasticsearch indexing skipped/failed: {exc}")
            print("Local JSON/CSV output is still available.")

    for a in investigated:
        print(f"[{a['severity'].upper()}] {a['rule']['name']} | "
              f"user={a['user']['name']} | source={a['source']['ip']}")

if __name__ == "__main__":
    main()
