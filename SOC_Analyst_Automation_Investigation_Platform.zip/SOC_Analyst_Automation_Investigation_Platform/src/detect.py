from collections import defaultdict
from datetime import datetime, timedelta, timezone
import uuid

def parse_timestamp(value):
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)

def detect_alerts(events, failed_threshold=5, window_minutes=10):
    if failed_threshold < 1 or window_minutes < 1:
        raise ValueError("Threshold and window must be positive")
    ordered = sorted(events, key=lambda e: parse_timestamp(e["@timestamp"]))
    failures = defaultdict(list)
    alerts, emitted = [], set()
    window = timedelta(minutes=window_minutes)

    for event in ordered:
        user = event.get("user", {}).get("name", "unknown")
        ip = event.get("source", {}).get("ip", "unknown")
        action = event.get("event", {}).get("action", "")
        ts = parse_timestamp(event["@timestamp"])
        key = (user, ip)

        if action == "login_failure":
            failures[key].append((ts, event))
            failures[key] = [(t, e) for t, e in failures[key] if ts - t <= window]
            if len(failures[key]) >= failed_threshold and key not in emitted:
                emitted.add(key)
                alerts.append({
                    "@timestamp": event["@timestamp"],
                    "alert": {"id": str(uuid.uuid4()), "status": "new"},
                    "rule": {"id": "AUTH-001", "name": "Multiple failed logins",
                             "description": f"{failed_threshold}+ failures for one user/IP in {window_minutes} minutes"},
                    "severity": "medium", "user": {"name": user}, "source": {"ip": ip},
                    "event_count": len(failures[key]),
                    "evidence": [{"@timestamp": e["@timestamp"], "event": e["event"],
                                  "message": e["message"]} for _, e in failures[key]],
                    "labels": {"synthetic": event.get("labels", {}).get("synthetic", False)}
                })

        elif action == "login_success":
            recent = [(t, e) for t, e in failures.get(key, [])
                      if ts - t <= window and t <= ts]
            dedupe = ("success_after_failures", user, ip, event["@timestamp"][:16])
            if len(recent) >= 3 and dedupe not in emitted:
                emitted.add(dedupe)
                evidence = [{"@timestamp": e["@timestamp"], "event": e["event"],
                             "message": e["message"]} for _, e in recent]
                evidence.append({"@timestamp": event["@timestamp"], "event": event["event"],
                                 "message": event["message"]})
                alerts.append({
                    "@timestamp": event["@timestamp"],
                    "alert": {"id": str(uuid.uuid4()), "status": "new"},
                    "rule": {"id": "AUTH-002", "name": "Successful login after repeated failures",
                             "description": "Successful login after 3+ recent failures for the same user/IP"},
                    "severity": "high", "user": {"name": user}, "source": {"ip": ip},
                    "event_count": len(evidence), "evidence": evidence,
                    "labels": {"synthetic": event.get("labels", {}).get("synthetic", False)}
                })
    return sorted(alerts, key=lambda a: a["@timestamp"])
