from datetime import datetime, timezone
from elasticsearch import Elasticsearch, helpers
from .config import (ELASTICSEARCH_URL, ELASTICSEARCH_API_KEY,
                     ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD)

def get_client():
    kwargs = {"hosts": [ELASTICSEARCH_URL], "request_timeout": 10}
    if ELASTICSEARCH_API_KEY:
        kwargs["api_key"] = ELASTICSEARCH_API_KEY
    elif ELASTICSEARCH_USERNAME:
        kwargs["basic_auth"] = (ELASTICSEARCH_USERNAME, ELASTICSEARCH_PASSWORD)
    return Elasticsearch(**kwargs)

def index_documents(prefix, documents):
    if not documents:
        return 0
    client = get_client()
    try:
        if not client.ping():
            raise ConnectionError(f"Cannot reach Elasticsearch at {ELASTICSEARCH_URL}")
        day = datetime.now(timezone.utc).strftime("%Y.%m.%d")
        actions = [{"_op_type": "index", "_index": f"{prefix}-{day}", "_source": doc}
                   for doc in documents]
        success, errors = helpers.bulk(client, actions, raise_on_error=False)
        if errors:
            print(f"Warning: {len(errors)} document(s) could not be indexed.")
        return success
    finally:
        client.close()
