import unittest
from src.detect import detect_alerts

class DetectionTests(unittest.TestCase):
    def test_five_failures_trigger_alert(self):
        events = []
        for i in range(5):
            events.append({
                "@timestamp": f"2026-01-01T00:0{i}:00Z",
                "event": {"action": "login_failure"},
                "user": {"name": "testuser"},
                "source": {"ip": "192.0.2.10"},
                "message": "synthetic test event",
                "labels": {"synthetic": True}
            })
        alerts = detect_alerts(events)
        self.assertTrue(any(a["rule"]["id"] == "AUTH-001" for a in alerts))

    def test_single_failure_does_not_trigger_alert(self):
        event = {
            "@timestamp": "2026-01-01T00:00:00Z",
            "event": {"action": "login_failure"},
            "user": {"name": "testuser"},
            "source": {"ip": "192.0.2.10"},
            "message": "synthetic test event",
            "labels": {"synthetic": True}
        }
        self.assertEqual(detect_alerts([event]), [])

if __name__ == "__main__":
    unittest.main()
